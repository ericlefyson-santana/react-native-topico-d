import React, { useState, useEffect } from 'react';
import { SafeAreaView, StyleSheet, View } from 'react-native';
import Gallery from 'react-native-image-gallery';

// Use "iOS" ou "Android", não "Web".

const App = () => {
  const [imagens, setImagens] = useState([]);

  useEffect(() => {
    let imagensIFAL = Array.apply(null, Array(4)).map((v, i) => {
      // Repetição que faz os sliders terem imagens com números diferentes
      return {
        source: {
          uri:
            'http://placehold.it/400x400/007500/FFFFFF/?text=' +
            (i + 511) +
            ' IFAL',
        },
      };
    });
    setImagens(imagensIFAL);
  }, []);

  return (
    <SafeAreaView style={styles.contentor}>
      <View style={styles.contentor}>
        <Gallery
          style={styles.estiloImagem}
          initialPage="1"
          // Imagem inicial
          images={imagens}
        />
      </View>
    </SafeAreaView>
  );
};

export default App;

const styles = StyleSheet.create({
  contentor: {
    flex: 1,
    justifyContent: 'center',
    marginTop: 15,
  },
  estiloImagem: {
    flex: 1,
    backgroundColor: '#007500',
  },
});
