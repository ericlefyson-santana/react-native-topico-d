import React, { Component } from 'react';
import {
  Text,
  TouchableOpacity,
  ScrollView,
  View,
  StyleSheet,
  Image
} from 'react-native';
import Expo, { Constants } from 'expo';
import * as Facebook from 'expo-facebook';

export default class App extends Component {
  state = {
    responseJSON: null,
  };
  callGraph = async token => {
    try {
      
    await Facebook.initializeAsync({
      appId: '333271441521483',
    });
    const {
      type,
      token,
      expirationDate,
      permissions,
      declinedPermissions,
    } = await Facebook.logInWithReadPermissionsAsync({
      permissions: ['public_profile'],
    });
    if (type === 'success') {
      // Get the user's name using Facebook's Graph API
      const response = await fetch(`https://graph.facebook.com/me?access_token=${token}`);
      alert('Logado com sucesso!', `Hi ${(await response.json()).name}!`);
    } else {
      // type === 'cancel'
    }
  } catch ({ message }) {
    alert(`Erro do Facebook: ${message}`);
  }
  };



  renderButton = () => (
    <TouchableOpacity onPress={() => this.callGraph()}>
      <View
        style={{
          width: '50%',
          alignSelf: 'center',
          borderRadius: 4,
          padding: 24,
          backgroundColor: '#3B5998',
        }}>
        <Text style={{ color: 'white', fontWeight: 'bold' }}>
          Login com o Facebook
        </Text>
      </View>
    </TouchableOpacity>
  );
  renderValue = value => (
    <Text key={value} style={styles.paragraph}>{value}</Text>
  );
  render() {
    return (
      <ScrollView style={styles.container}>
      <Text style={{color:'#fff', fontWeight:'bold', fontSize:18, textAlign:'center'}}>Página do Participante</Text>
      <Text style={{color:'#fff', marginTop:10, marginBottom:10, fontSize:16, textAlign:'center'}}>Jogos Internos IFAL</Text>
        {this.state.responseJSON &&
          this.renderValue('User data : ' + this.state.responseJSON)}

        {this.renderButton()}
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#333',
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#34495e',
  },
});
