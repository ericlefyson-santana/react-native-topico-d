import React, { Component } from 'react';
import { Image, StyleSheet } from 'react-native';
import ImageMapper from 'react-native-image-mapper';



export default class App extends Component {

 
 
  render() {
    return (
      <ImageMapper 
          imgSource={{uri: 'https://i.imgur.com/6HCevbk.png'}}
          imgHeight={700}
          imgWidth={400} 
          style ={styles.image}
          imgMap={RECTANGLE_MAP} 
          selectedAreaId={'0'}
          onPress = {(item, idx, event) => alert("Código feito por Arthur, e ele funciona")(item, idx, event)}/>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: "column"
  },
  image: {
    flex: 1,
    resizeMode: "cover",
    justifyContent: "center"
  },
  text: {
    color: "white",
    fontSize: 42,
    fontWeight: "bold",
    textAlign: "center",
    backgroundColor: "#000000a0"
  }
});

const RECTANGLE_MAP = [
  {
    id: '0',
    name: 'Retangulo',
    shape: 'rectangle',
    x2: 700,
    y2: 700,
    x1: 1, 
    y1: 1,
    prefill: 'null',
    fill: ''
  }
]
