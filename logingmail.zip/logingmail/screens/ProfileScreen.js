import React from "react";
import { StyleSheet, Text, View } from "react-native";

const ProfileScreen = ({ route, navigation }) => {
  const { user } = route.params;
  console.log("user from google", user);
  return (
    <View style={{flex:1, backgroundColor:'#333'}}>
      <Text style={{textAlign:'center', marginTop:30, color:'#fff'}}>Perfil do Participante</Text>
      <Text style={{textAlign:'center', marginTop:30, color:'#fff'}}>Bem Vindo {user.name} !</Text>
    </View>
  );
};

export default ProfileScreen;

