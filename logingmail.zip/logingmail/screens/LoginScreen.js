import React from "react";
import { StyleSheet,  KeyboardAvoidingView, TextInput, TouchableOpacity, Image, Text, View, Button } from "react-native";
import * as Google from "expo-google-app-auth";
import {css} from '../assets/css/css';
import * as Facebook from 'expo-facebook';

const LoginScreen = ({ navigation }) => {
    const callGraph = async token => {
    try {
    await Facebook.initializeAsync({
      appId: '333271441521483',
    });
    const {
      type,
      token,
      expirationDate,
      permissions,
      declinedPermissions,
    } = await Facebook.logInWithReadPermissionsAsync({
      permissions: ['public_profile'],
    });
    if (type === 'success') {
      // Get the user's name using Facebook's Graph API
      const response = await fetch(`https://graph.facebook.com/me?access_token=${token}`);
      console.log('Usuário Logado!', `Olá ${(await response.json()).name}!`);
    } else {
      // type === 'cancel'
    }
  } catch ({ message }) {
    console.log(`Mensagem de erro: ${message}`);
  }
  };


  const signInAsync = async () => {
    console.log("Iniciando Login");
    try {
      const { type, user } = await Google.logInAsync({
        androidClientId: `921012771044-ieii71gc47pvu2qqjl1dk8lm00i9rp97.apps.googleusercontent.com`,
      });

      if (type === "success") {
        // Then you can use the Google REST API
        console.log("Login concluído com sucesso");
        navigation.navigate("Profile", { user });
      }
    } catch (error) {
      console.log("Erro Com o login", error);
    }
  };

  return (
    <KeyboardAvoidingView  style={[css.container, css.darkbg]}>
      <Text style={{color:'#fff', fontWeight:'bold', fontSize:18}}>Página do Participante</Text>
      <Text style={{color:'#fff', marginTop:10, marginBottom:10, fontSize:16}}>Jogos Internos IFAL</Text>
            <View style={css.login__logomarca}>
                <Image source={require('../assets/img/ifal.png')} />
            </View>

            <View style={css.login__form}>
                <TextInput style={css.login__input} placeholder='Usuário:' />
                <TextInput style={css.login__input} placeholder='Senha:' secureTextEntry={true} />
                <TouchableOpacity style={css.login__button} onPress={()=>console.log('teste')}>
                    <Text style={css.login__buttonText}>Entrar</Text>
                </TouchableOpacity>
                      <View style={styles.container}>
    <Text style={{textAlign:'center', color: '#333' }}>Jogos Internos do Ifal</Text>
      <Button title="Login com o google" onPress={signInAsync} />
      <TouchableOpacity style={{backgroundColor:'#333', paddingTop:30}} onPress={callGraph}>
      <View
        style={{
          width: '100%',
          alignSelf: 'center',
          borderRadius: 4,
          padding: 10,
          backgroundColor: '#3B5998',
          textAlign:'center'
        }}>
        <Text style={{ color: 'white', fontWeight: 'bold' }}>
          LOGIN COM FACEBOOK
        </Text>
      </View>
    </TouchableOpacity>
    </View>
            </View>
        </KeyboardAvoidingView>

  );
};

export default LoginScreen;

const styles = StyleSheet.create({});