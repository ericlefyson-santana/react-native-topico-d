import React, { useState, useEffect } from 'react';
import { SafeAreaView, StyleSheet, View, FlatList, Image } from 'react-native';

const App = () => {
  const [imagens, setImagens] = useState([]);

  useEffect(() => {
    let imagensIFAL = Array.apply(null, Array(4)).map((v, i) => {
      // Repetição que faz as imagens terem números diferentes
      return {
        id: i,
        src:
          'http://placehold.it/400x400/007500/FFFFFF/?text=' +
          (i + 511) +
          ' IFAL',
      };
    });
    setImagens(imagensIFAL);
  }, []);

  return (
    <SafeAreaView style={styles.contentor}>
      <FlatList
        data={imagens}
        renderItem={({ item }) => (
          <View style={styles.estiloImagens}>
            <Image style={styles.imagemMiniatura} source={{ uri: item.src }} />
          </View>
        )}
        // Número de colunas
        numColumns={2}
        keyExtractor={(item, index) => index}
      />
    </SafeAreaView>
  );
};
export default App;

const styles = StyleSheet.create({
  contentor: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#007500',
    marginTop: 30,
  },
  imagemMiniatura: {
    justifyContent: 'center',
    alignItems: 'center',
    height: 150,
  },
  estiloImagens: {
    flex: 1,
    flexDirection: 'column',
    margin: 2,
  },
});
